import React from 'react'
import { Outlet, Link } from 'react-router-dom'
export default function App(){
  const user = JSON.parse(localStorage.getItem('user')||'null');
  return (<div style={{fontFamily:'Arial',padding:20}}>
    <header style={{display:'flex',justifyContent:'space-between',alignItems:'center'}}>
      <div><strong style={{color:'#0b3d91'}}>SkyTrust Bank</strong></div>
      <nav>
        <Link to='/'>Home</Link> | <Link to='/login'>Login</Link> | <Link to='/register'>Register</Link>
      </nav>
    </header>
    <hr/>
    <Outlet />
  </div>);
}
