import React, { useState } from 'react';
import api from '../api';
import { useNavigate } from 'react-router-dom';
export default function Login(){
  const [email,setEmail]=useState(''); const [password,setPassword]=useState('');
  const nav = useNavigate();
  async function submit(e){ e.preventDefault(); try{ const { data } = await api.post('/auth/login', { email, password }); localStorage.setItem('token', data.token); localStorage.setItem('user', JSON.stringify(data.user)); alert('Logged in'); nav('/'); } catch(err){ alert(err.response?.data?.error || err.message); } }
  return (<form onSubmit={submit}><h2>Login</h2><input placeholder='Email' value={email} onChange={e=>setEmail(e.target.value)} /><br/><input placeholder='Password' type='password' value={password} onChange={e=>setPassword(e.target.value)} /><br/><button type='submit'>Login</button></form>);
}
