import React, { useEffect, useState } from 'react';
import api from '../api';
export default function Dashboard(){
  const [profile,setProfile]=useState(null);
  useEffect(()=>{ async function load(){ try{ const token = localStorage.getItem('token'); if(!token) return; const res = await api.get('/users/me', { headers:{ Authorization: 'Bearer ' + token } }); setProfile(res.data); }catch(e){} } load(); },[]);
  if(!profile) return <div><h2>Welcome to SkyTrust Bank</h2><p>Please login or register</p></div>
  return (<div><h2>Dashboard</h2><div>{profile.name} - {profile.email}</div><div>Account: {profile.Account?.accountNumber} - Balance: {profile.Account?.balance} {profile.Account?.currency}</div></div>);
}
