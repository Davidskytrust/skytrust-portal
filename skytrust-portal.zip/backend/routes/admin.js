const express = require('express');
const router = express.Router();
const { authRequired, adminRequired } = require('../middleware/auth');
const { User, Account, Transaction, SupportTicket, sequelize } = require('../models');
const nodemailer = require('nodemailer');
require('dotenv').config();
const transporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST,
  port: Number(process.env.SMTP_PORT||587),
  secure: false,
  auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS }
});
// list users
router.get('/users', authRequired, adminRequired, async (req,res)=>{ const users = await User.findAll({ include: Account }); res.json(users); });
// pending users
router.get('/pending', authRequired, adminRequired, async (req,res)=>{ const list = await User.findAll({ where:{ status:'pending' } }); res.json(list); });
// approve user
router.post('/users/:id/approve', authRequired, adminRequired, async (req,res)=>{ const u = await User.findByPk(req.params.id); if(!u) return res.status(404).json({ error:'Not found' }); u.status='active'; await u.save(); // notify by email
try{ await transporter.sendMail({ from: process.env.SMTP_USER, to: u.email, subject:'SkyTrust: Account approved', text:'Your account has been approved. You can now login.' }); }catch(e){ console.error('mail',e.message); } res.json({ success:true }); });
// block/unblock
router.post('/users/:id/block', authRequired, adminRequired, async (req,res)=>{ const u = await User.findByPk(req.params.id); if(!u) return res.status(404).json({ error:'Not found' }); u.status = 'blocked'; await u.save(); res.json({ success:true }); });
router.post('/users/:id/unblock', authRequired, adminRequired, async (req,res)=>{ const u = await User.findByPk(req.params.id); if(!u) return res.status(404).json({ error:'Not found' }); u.status = 'active'; await u.save(); res.json({ success:true }); });
// adjust balance
router.post('/account/adjust', authRequired, adminRequired, async (req,res)=>{ const { userId, amount, type, reason } = req.body; if(!userId||!amount||!type) return res.status(400).json({ error:'Missing' }); const acc = await Account.findOne({ where:{ userId } }); if(!acc) return res.status(404).json({ error:'Account not found' }); const t = await sequelize.transaction(); try{ const amt = parseFloat(amount); if(type==='credit'){ await acc.increment({ balance: amt }, { transaction: t }); await Transaction.create({ accountId: acc.id, type:'credit', amount: amt }, { transaction: t }); } else { const bal = parseFloat(acc.balance); if(bal < amt){ await t.rollback(); return res.status(400).json({ error:'Insufficient' }); } await acc.decrement({ balance: amt }, { transaction: t }); await Transaction.create({ accountId: acc.id, type:'debit', amount: amt }, { transaction: t }); } await t.commit(); res.json({ success:true }); }catch(e){ await t.rollback(); res.status(500).json({ error: e.message }); }});
// tickets list
router.get('/tickets', authRequired, adminRequired, async (req,res)=>{ const tickets = await SupportTicket.findAll({ include: User }); res.json(tickets); });
module.exports = router;
