const express = require('express');
const router = express.Router();
const { authRequired } = require('../middleware/auth');
const { SupportTicket } = require('../models');
const nodemailer = require('nodemailer');
require('dotenv').config();
const transporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST,
  port: Number(process.env.SMTP_PORT||587),
  secure: false,
  auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS }
});
router.post('/create', authRequired, async (req,res)=>{ const { subject, message } = req.body; if(!subject||!message) return res.status(400).json({ error:'Missing' }); const ticket = await SupportTicket.create({ subject, message, userId: req.user.id }); try{ await transporter.sendMail({ from: process.env.SMTP_USER, to: process.env.SUPPORT_EMAIL || process.env.SMTP_USER, subject: `Support: ${subject}`, text: `From: ${req.user.email}\n\n${message}\nTicket: ${ticket.id}` }); }catch(e){ console.error('mail', e.message); } res.json(ticket); });
router.get('/mine', authRequired, async (req,res)=>{ const tickets = await SupportTicket.findAll({ where:{ userId: req.user.id }, order:[['createdAt','DESC']] }); res.json(tickets); });
module.exports = router;
