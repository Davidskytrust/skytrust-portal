const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken');
const { User, Account } = require('../models');
require('dotenv').config();
const JWT_SECRET = process.env.JWT_SECRET || 'devsecret';
router.post('/register', async (req,res)=>{ const { name,email,password } = req.body; if (!name||!email||!password) return res.status(400).json({ error:'Missing fields' }); try{ const user = await User.create({ name, email, passwordHash: password, status:'pending' }); const accNumber = String(2000000000 + Math.floor(Math.random()*800000000)); await Account.create({ accountNumber: accNumber, userId: user.id, currency:'USD', balance: 0.00 }); res.json({ message:'Registered, pending approval' }); } catch(e){ res.status(400).json({ error: e.message }); }});
router.post('/login', async (req,res)=>{ const { email,password } = req.body; if (!email||!password) return res.status(400).json({ error:'Missing' }); try{ const user = await User.findOne({ where:{ email } }); if (!user) return res.status(401).json({ error:'Invalid credentials' }); const ok = await user.validatePassword(password); if (!ok) return res.status(401).json({ error:'Invalid credentials' }); if (user.status !== 'active' && user.role !== 'admin') return res.status(403).json({ error:'Account not active' }); const token = jwt.sign({ id: user.id }, JWT_SECRET, { expiresIn:'7d' }); // update last login
user.lastLoginAt = new Date(); await user.save(); res.json({ token, user:{ id: user.id, name: user.name, email: user.email, role: user.role, status: user.status } }); } catch(e){ res.status(500).json({ error: e.message }); }});
module.exports = router;
