const { DataTypes } = require('sequelize');
const sequelize = require('../db');
const Account = sequelize.define('Account', {
  id:{ type: DataTypes.UUID, primaryKey:true, defaultValue: DataTypes.UUIDV4 },
  accountNumber:{ type: DataTypes.STRING, allowNull:false, unique:true },
  currency:{ type: DataTypes.STRING, allowNull:false, defaultValue:'USD' },
  balance:{ type: DataTypes.DECIMAL(20,2), allowNull:false, defaultValue:0.00 }
}, { timestamps:true });
module.exports = Account;
