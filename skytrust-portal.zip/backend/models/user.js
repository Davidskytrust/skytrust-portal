const { DataTypes } = require('sequelize');
const sequelize = require('../db');
const bcrypt = require('bcrypt');
const User = sequelize.define('User', {
  id:{ type: DataTypes.UUID, primaryKey:true, defaultValue: DataTypes.UUIDV4 },
  name:{ type: DataTypes.STRING, allowNull:false },
  email:{ type: DataTypes.STRING, allowNull:false, unique:true, validate:{ isEmail:true } },
  passwordHash:{ type: DataTypes.STRING, allowNull:false },
  role:{ type: DataTypes.ENUM('user','admin'), defaultValue:'user' },
  status:{ type: DataTypes.ENUM('pending','active','blocked','rejected'), defaultValue:'pending' },
  lastLoginAt:{ type: DataTypes.DATE, allowNull:true },
  lastLoginIp:{ type: DataTypes.STRING, allowNull:true }
}, { timestamps:true });
User.prototype.validatePassword = function(pw){ return bcrypt.compare(pw, this.passwordHash); };
User.beforeCreate(async (user)=>{ if (user.passwordHash && !user.passwordHash.startsWith('$2')){ const s = await bcrypt.genSalt(10); user.passwordHash = await bcrypt.hash(user.passwordHash, s); }});
module.exports = User;
