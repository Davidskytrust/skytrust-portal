const { DataTypes } = require('sequelize');
const sequelize = require('../db');
const SupportTicket = sequelize.define('SupportTicket', {
  id:{ type: DataTypes.UUID, primaryKey:true, defaultValue: DataTypes.UUIDV4 },
  subject:{ type: DataTypes.STRING, allowNull:false },
  message:{ type: DataTypes.TEXT, allowNull:false },
  status:{ type: DataTypes.ENUM('open','in_progress','resolved','closed'), defaultValue:'open' },
  replies:{ type: DataTypes.JSON, defaultValue:[] }
}, { timestamps:true });
module.exports = SupportTicket;
