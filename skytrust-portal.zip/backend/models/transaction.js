const { DataTypes } = require('sequelize');
const sequelize = require('../db');
const Transaction = sequelize.define('Transaction', {
  id:{ type: DataTypes.UUID, primaryKey:true, defaultValue: DataTypes.UUIDV4 },
  type:{ type: DataTypes.ENUM('credit','debit','transfer_out','transfer_in','fee'), allowNull:false },
  amount:{ type: DataTypes.DECIMAL(20,2), allowNull:false },
  currency:{ type: DataTypes.STRING, allowNull:false, defaultValue:'USD' },
  meta:{ type: DataTypes.JSON, allowNull:true }
}, { timestamps:true });
module.exports = Transaction;
