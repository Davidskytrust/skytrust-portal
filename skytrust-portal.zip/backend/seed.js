const { sequelize, User, Account } = require('./models');
async function run(){
  await sequelize.sync({ force:true });
  const admin = await User.create({ name:'Support Team', email:'admin@skytrust.bank', passwordHash:'Admin123!', role:'admin', status:'active' });
  const demo = await User.create({ name:'David Demo', email:'david@skytrust.bank', passwordHash:'User123!', role:'user', status:'active' });
  await Account.create({ accountNumber:'1000000001', userId: admin.id, currency:'USD', balance:1000.00 });
  await Account.create({ accountNumber:'2000000001', userId: demo.id, currency:'USD', balance:500.00 });
  console.log('Seed created. Admin: admin@skytrust.bank / Admin123!  Demo: david@skytrust.bank / User123!');
  process.exit(0);
}
run();
