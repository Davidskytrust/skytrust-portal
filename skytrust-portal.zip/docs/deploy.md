# Deploy to Vercel (frontend) and Render (backend) - simple guide

## Frontend (Vercel)
1. Go to https://vercel.com and sign up.
2. Create a new project -> Import from GitHub -> choose the repo `Davidskytrust/skytrust-portal` -> select the `frontend` directory.
3. Set Environment Variable: VITE_API_BASE = https://<your-backend-url>/api
4. Deploy.

## Backend (Render)
1. Go to https://render.com and sign up.
2. Create -> Web Service -> connect to GitHub repo and select `backend` folder.
3. Set Build Command: `npm install`
   Start Command: `npm start`
4. Set Environment Variables (in Render):
   - JWT_SECRET: a long secret
   - DATABASE_FILE: ./database.sqlite
   - SMTP_HOST / SMTP_PORT / SMTP_USER / SMTP_PASS
   - SUPPORT_EMAIL: trustsky297@gmail.com
5. Deploy. Copy the backend URL and set VITE_API_BASE in Vercel.

