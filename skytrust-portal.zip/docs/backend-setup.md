# Backend Local Setup (simple)
1. Install Node.js (v18+)
2. On your computer, open a terminal and run:
   cd skytrust-portal/backend
   npm install
   cp .env.example .env
   # Edit .env to set SMTP credentials if you want emails to send
   npm run seed
   npm run dev
3. Backend will run at http://localhost:4000
