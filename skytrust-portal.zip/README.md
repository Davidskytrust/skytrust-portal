# SkyTrust Portal (Starter)
This repository contains a minimal starter for the SkyTrust Bank project.
Folders:
- backend: Node.js + Express + SQLite (demo)
- frontend: Vite + React (demo)
Follow docs/backend-setup.md and docs/deploy.md for simple deployment instructions.
